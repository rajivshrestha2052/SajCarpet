from rest_framework.routers import DefaultRouter
from django.urls import path, include
from api.views.category import CategoryPublicViewSet
from api.views.product import ProductViewSet, ProductOperation
from api.views.order import OrderViewSet
from api.views.customer import UserViewSet, CustomerViewSet

router = DefaultRouter()
router.register(r'categories', CategoryPublicViewSet, basename='categories')
router.register(r'productscrud', ProductOperation, basename= 'productscrud')
router.register(r'products', ProductViewSet, basename='products')
router.register(r'orders', OrderViewSet, basename='orders')
router.register(r'customers', CustomerViewSet, basename='customers')

urlpatterns = router.urls