from .category import CategoryViewSet
from .customer import CustomerViewSet, UserViewSet
from .product import ProductViewSet, StandardResultsSetPagination
from .order import OrderViewSet